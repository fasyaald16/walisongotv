<?php
$conn = mysqli_connect("localhost", "root", "", "walisongo_tv");

if ($conn) {
    echo "Koneksi ke database BERHASIL!";
} else {
    echo "Koneksi GAGAL: " . mysqli_connect_error();
}
?>