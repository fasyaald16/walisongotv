<?php
session_start();
require '../koneksi.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../auth/login.php");
    exit;
}

// Ambil input
$identity = trim($_POST['identity'] ?? '');
$password = trim($_POST['password'] ?? '');

// Validasi input kosong
if (empty($identity) || empty($password)) {
    $_SESSION['error'] = "Email/NIM dan Password harus diisi!";
    header("Location: ../index.html");
    exit;
}

// Cek apakah input email atau NIM
if (filter_var($identity, FILTER_VALIDATE_EMAIL)) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
} else {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE nim = ?");
}

// Eksekusi query
$stmt->execute([$identity]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Cek user dan password
if ($user && password_verify($password, $user['password'])) {

    // Login sukses
    session_regenerate_id(true);
    $_SESSION['login'] = true;
    $_SESSION['id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['nama'] = $user['nama_lengkap'];
    $_SESSION['photo'] = $user['photo'];

    // Redirect sesuai role
    if ($user['role'] === 'admin') {
        header("Location: ../admin/dashboard.php");
    } else {
        header("Location: ../auth/index.php");
    }
    exit;

} else {
    // =======================
    // ERROR LOGIN
    // =======================
    $_SESSION['error'] = "Email/NIM atau Password salah!";
    header("Location: ../index.html");
    exit;

} 


// $user = mysqli_fetch_assoc($query);

// if ($user && password_verify($password, $user['password'])) {

//     session_regenerate_id(true);

//     $_SESSION['login'] = true;
//     $_SESSION['id'] = $user['id'];
//     $_SESSION['role'] = $user['role'];
//     $_SESSION['nama'] = $user['nama_lengkap'];
//     $_SESSION['photo'] = $user['photo'];
    
//     // redirect sesuai role
//     if ($user['role'] == 'admin') {
//         header("Location: ../admin/dashboard.php");
//     } else {
//         header("Location: ../auth/index.php");
//     }

// } else {
//     // =======================
//     // ERROR LOGIN
//     // =======================
//     $_SESSION['error'] = "Email/NIM atau Password salah!";
//     header("Location: login.php");
//     exit;
// }
?>

