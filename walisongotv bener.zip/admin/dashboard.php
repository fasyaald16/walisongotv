<?php
session_start();

// anti cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");

// harus login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

// hanya admin
if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
?>

<h1>Dashboard Admin</h1>
<p>Welcome, <?= $_SESSION['nama']; ?></p>
<!-- logout -->
<html>
<button onclick="window.location.href='../logout.php'">Logout</button>


</html>